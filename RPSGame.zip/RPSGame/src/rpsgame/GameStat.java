/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpsgame;

import java.util.HashMap;
/**
 *
 * @author Surya
 */
public class GameStat {

    private int userWins, computerWins, ties;
    private HashMap<Integer, Integer> userGestureCounts = new HashMap<Integer, Integer>();
    private HashMap<Integer, Integer> computerGestureCounts = new HashMap<Integer, Integer>();
    
    /*********************************************************************
    * Constructor:
    * Parameters:   [none]
    * Description:  constructor to set totals to zero
    ********************************************************************/
    public GameStat()      //constructor to set totals to zero
    {       
        userWins = 0;
        computerWins = 0;
        ties = 0;
       
        // Initialize user gesture counts to 0
        userGestureCounts.put(1, 0); // rock
        userGestureCounts.put(2, 0); // paper
        userGestureCounts.put(3, 0); // scissors
        
        computerGestureCounts.put(1, 0); // rock
        computerGestureCounts.put(2, 0); // paper
        computerGestureCounts.put(3, 0); // scissors 
    }
    
    /*********************************************************************
    * Method:       update
    * Parameters:   computerWin, userWin, tie, userGesture, computerGesture
    * Description:  updates the game stats to respective parameters
    ********************************************************************/
    public void update(int computerWin, int userWin, int tie, int userGesture, int computerGesture) {
        userWins += userWin;
        computerWins += computerWin;
        ties += tie;
        userGestureCounts.put(userGesture, userGestureCounts.get(userGesture)+1);
        computerGestureCounts.put(computerGesture, computerGestureCounts.get(computerGesture)+1);
    }
    
    /*********************************************************************
    * Method:       getWinner
    * Parameters:   [none]
    * Description:  returns a string indicating which player won based on totals
    ********************************************************************/
    public String getWinner()
    {
        if (computerWins > userWins)
        {
            return "Computer";
        }
        else if (userWins > computerWins)
        {
            return "User";
        }
        else
        {       
            return "Tie"; 
        }
    }
    
     
    public int getUserWins() {
        return userWins;
    }

   
    public void setUserWins(int userWins) {
        this.userWins = userWins;
    }
 
    public int getComputerWins() {
        return computerWins;
    }

      
    public void setComputerWins(int computerWins) {
        this.computerWins = computerWins;
    }

    
    public int getTies() {
        return ties;
    }

   
    public void setTies(int ties) {
        this.ties = ties;
    }

    
    public HashMap<Integer, Integer> getUserGestureCounts() {
        return userGestureCounts;
    }

      
    public void setUserGestureCounts(HashMap<Integer, Integer> userGestureCounts) {
        this.userGestureCounts = userGestureCounts;
    }
   
    public HashMap<Integer, Integer> getComputerGestureCounts() {
        return computerGestureCounts;
    }

    
    public void setComputerGestureCounts(HashMap<Integer, Integer> computerGestureCounts) {
        this.computerGestureCounts = computerGestureCounts;
    }

}

