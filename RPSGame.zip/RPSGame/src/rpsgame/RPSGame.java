/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Surya
 */
package rpsgame;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;

public class RPSGame {
    
    private String[] gestureNamesAL = {"rock", "paper", "scissors"};//Array of String containing gesture names
    private ArrayList<Integer> userGestureHistoryAL = new ArrayList<Integer>();//ArrayList to capture user gestures history
    private GameStat stats = new GameStat();//GameStat to capture all the stats
    
    /*********************************************************************
    * Method:       playOneRound
    * Parameters:   inUserChoice
    * Description:  This method returns the final result of the round.
    ********************************************************************/
    String playOneRound(int inUserChoice) {
        userGestureHistoryAL.add(inUserChoice);
        int computerChoice = getComputerChoice() ;
        int result = (inUserChoice - computerChoice + 3)%3;
        if(result == 0) {
            stats.update(0,0,1,inUserChoice,computerChoice);
            return "YOUR GESTURE IS "+gestureNamesAL[inUserChoice-1]+". COMPUTER GESTURE IS "+gestureNamesAL[computerChoice-1]+". RESULT: TIE";
        } else if(result == 1) {
            stats.update(0,1,0,inUserChoice,computerChoice);
            return "YOUR GESTURE IS "+gestureNamesAL[inUserChoice-1]+". COMPUTER GESTURE IS "+gestureNamesAL[computerChoice-1]+". RESULT: PLAYER WINS!";
        } else {
            stats.update(1,0,0,inUserChoice,computerChoice);
            return "YOUR GESTURE IS "+gestureNamesAL[inUserChoice-1]+". COMPUTER GESTURE IS "+gestureNamesAL[computerChoice-1]+". RESULT: COMPUTER WINS!";
        }
    }
    
    /*********************************************************************
    * Method:       getComputerChoice
    * Parameters:   [none]
    * Description:  This method is used to get the computers choice
    ********************************************************************/
    int getComputerChoice() {
        int computerChoice = 0;
        Random randomGenerator = new Random();
        if(userGestureHistoryAL.size() == 1) {
            try {
                BufferedReader br = new BufferedReader(new FileReader("./compChoice.txt"));
                computerChoice = Integer.parseInt(br.readLine());
            } catch(Exception e) {
                e.printStackTrace();
            }
        } else if(userGestureHistoryAL.size() >= 2 && userGestureHistoryAL.size() <= 4){
            computerChoice = randomGenerator.nextInt(3)+1;
        } else if(userGestureHistoryAL.size() == 5){
            computerChoice = userGestureHistoryAL.get(3);
        } else {
            computerChoice = randomGenerator.nextInt(3)+1;
        }
        return computerChoice;
    }
    
    /*********************************************************************
    * Method:       getGameStat
    * Parameters:   [none]
    * Description:  This method returns game statistics
    ********************************************************************/
    public GameStat getGameStat() {
        return stats;
    }
    
    /*********************************************************************
    * Method:       getGameStat
    * Parameters:   [none]
    * Description:  This method returns gestures names.
    ********************************************************************/   
    public String[] getGestureNamesAL() {
        return gestureNamesAL;
    }

    /*********************************************************************
    * Method:       getUserGestureHistoryAL
    * Parameters:   [none]
    * Description:  This method returns player gestures.
    ********************************************************************/    
    public ArrayList<Integer> getUserGestureHistoryAL() {
        return userGestureHistoryAL;
    }
}
