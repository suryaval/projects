/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rpsgame;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.HashMap;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;


/**
 *
 * @author Surya
 */
public class RPSGameApp extends JFrame implements ActionListener,ListSelectionListener {
    HashMap<String, GameStat> gameStats = new HashMap<>();
    private static Date startDate = null;
    
    private final JButton startGameButn = new JButton("Start New Game"); 
    private final JButton goButton = new JButton("GO");

    
    private final DefaultListModel<String> model = new DefaultListModel<>();
    private final JList<String> finishedGamesList = new JList<>(model);
    private final JScrollPane gamesListPane = new JScrollPane(finishedGamesList, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

    private final JTextArea roundResultsTA = new JTextArea(15,50);
    private final JScrollPane outputAreaPaneScroll = new JScrollPane(roundResultsTA);
    
    private final JRadioButton rockButton = new JRadioButton("ROCK");
    private final JRadioButton paperButton = new JRadioButton("PAPER");
    private final JRadioButton scissorsButton = new JRadioButton("SCISSORS");
    
    private final JTextField rockTextField = new JTextField();
    private final JTextField paperextField = new JTextField();
    private final JTextField scissorsTextField = new JTextField();
    private final JTextField rockCompTextField = new JTextField();
    private final JTextField paperCompTextField = new JTextField();
    private final JTextField sciccorsCompTextF = new JTextField();
    private final JTextField noOfTies = new JTextField();
    private final JTextField winner = new JTextField();
   
    private RPSGame currentGameRPS = null;
    private int userselection = 0;
    
    public static void main(String args[]){  
        createAndShowGUI();
    }
    
    public static void createAndShowGUI() {
        RPSGameApp frame1 = new RPSGameApp(); 
        
        frame1.setDefaultCloseOperation(EXIT_ON_CLOSE);
        frame1.setResizable(false);
        frame1.pack();
        frame1.setVisible(true);
    }
    
    public RPSGameApp() {                           
        super("Welcome to Rock Paper Scissors");              
        setLayout(new BorderLayout());               

        currentGameRPS = new RPSGame(); 
        startDate = new Date();
        
        
        JPanel  westPanel= new JPanel(new BorderLayout());
        //westPanel.add(new JLabel("Game Timings"));
        Color c1 = new Color(10, 170, 70);  
        westPanel.setBackground(c1);
        add(westPanel, BorderLayout.WEST);
        
        
        
        westPanel.add(gamesListPane, BorderLayout.NORTH);
        finishedGamesList.addListSelectionListener(this);
        
        JPanel  statsPanel= new JPanel(new BorderLayout()); 
        statsPanel.setBackground(c1);
        westPanel.add(statsPanel, BorderLayout.SOUTH);
        
        JPanel  countPanel= new JPanel(new GridLayout(3, 4)); 
        countPanel.setBackground(c1);
        countPanel.add(new JLabel("          "));
        countPanel.add(new JLabel("ROCK"));
        countPanel.add(new JLabel("PAPER"));
        countPanel.add(new JLabel("SCISSORS"));
        countPanel.add(new JLabel("PLAYER"));
        countPanel.add(rockTextField);
        countPanel.add(paperextField);
        countPanel.add(scissorsTextField);
        countPanel.add(new JLabel("COMPUTER"));
        countPanel.add(rockCompTextField);
        countPanel.add(paperCompTextField);
        countPanel.add(sciccorsCompTextF);
   
        statsPanel.add(countPanel, BorderLayout.NORTH);
          
        JPanel  resultsPanel= new JPanel(new GridLayout(2, 2)); 
        resultsPanel.setBackground(c1);
        resultsPanel.add(new JLabel("No of Ties:"));
        resultsPanel.add(noOfTies);
        resultsPanel.add(new JLabel("Winner"));
        resultsPanel.add(winner);
        statsPanel.add(resultsPanel, BorderLayout.SOUTH);
        
        JPanel  eastPanel= new JPanel(new BorderLayout()); 
        add(eastPanel, BorderLayout.EAST);
        
        JPanel  controlPanel = new JPanel(new GridLayout(2, 1)); 
        eastPanel.add(controlPanel, BorderLayout.NORTH);
        
        JPanel  startPanel = new JPanel(new FlowLayout()); 
        startPanel.setBackground(Color.YELLOW);
        startPanel.add(startGameButn);
        controlPanel.add(startPanel);
        
        JPanel  inputChoicePanel = new JPanel(new FlowLayout()); 
        inputChoicePanel.setBackground(Color.YELLOW);
        
        rockButton.setBackground(Color.YELLOW);
        rockButton.addActionListener(this);
       
        paperButton.setBackground(Color.YELLOW);
        paperButton.addActionListener(this);
        
        scissorsButton.setBackground(Color.YELLOW);
        scissorsButton.addActionListener(this);
        
        ButtonGroup group = new ButtonGroup();
        group.add(rockButton);
        group.add(paperButton);
        group.add(scissorsButton);
        
        inputChoicePanel.add(rockButton);
        inputChoicePanel.add(paperButton);
        inputChoicePanel.add(scissorsButton);
        inputChoicePanel.add(goButton);
        
        controlPanel.add(inputChoicePanel);
        
        JPanel southPanel = new JPanel();
        eastPanel.add(southPanel, BorderLayout.SOUTH);
        
        southPanel.add(outputAreaPaneScroll);
    
        startGameButn.addActionListener(this);
        goButton.addActionListener(this);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == startGameButn) {
            if (currentGameRPS != null) {
                GameStat gameStat = currentGameRPS.getGameStat();
                gameStats.put(startDate.toString(), gameStat);
                model.addElement(startDate.toString());
                rockTextField.setText(gameStat.getUserGestureCounts().get(1).toString());
                paperextField.setText(gameStat.getUserGestureCounts().get(2).toString());
                scissorsTextField.setText(gameStat.getUserGestureCounts().get(3).toString());
                rockCompTextField.setText(gameStat.getComputerGestureCounts().get(1).toString());
                paperCompTextField.setText(gameStat.getComputerGestureCounts().get(2).toString());
                sciccorsCompTextF.setText(gameStat.getComputerGestureCounts().get(3).toString());
                noOfTies.setText(Integer.toString(gameStat.getTies()));
                winner.setText(gameStat.getWinner());
                currentGameRPS = new RPSGame();
                startDate = new Date();
                rockButton.setEnabled(true);
                paperButton.setEnabled(true);
                scissorsButton.setEnabled(true);
                goButton.setEnabled(true);
                roundResultsTA.setText(null);
            } else {
                currentGameRPS = new RPSGame();
                startDate = new Date();
                rockButton.setEnabled(true);
                paperButton.setEnabled(true);
                scissorsButton.setEnabled(true);
                goButton.setEnabled(true);
                roundResultsTA.setText(null);
            }
        } else if(e.getSource() == rockButton) {
            userselection = 1;
        } else if(e.getSource() == paperButton) {
            userselection = 2;
        } else if(e.getSource() == scissorsButton) {
            userselection = 3;              
        } else if(e.getSource() == goButton) {
            String result = currentGameRPS.playOneRound(userselection);
            roundResultsTA.append(result+"\n");
        }
    }
    
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if(!finishedGamesList.isSelectionEmpty()) {
            String key = (String)finishedGamesList.getSelectedValue();
            GameStat gameStat = gameStats.get(key);
            rockTextField.setText(gameStat.getUserGestureCounts().get(1).toString());
            rockTextField.setFont(new Font("monospace", Font.BOLD, 20));
            paperextField.setText(gameStat.getUserGestureCounts().get(2).toString());
            paperextField.setFont(new Font("monospace", Font.BOLD, 20));
            scissorsTextField.setText(gameStat.getUserGestureCounts().get(3).toString());
            scissorsTextField.setFont(new Font("monospace", Font.BOLD, 20));
            rockCompTextField.setText(gameStat.getComputerGestureCounts().get(1).toString());
            rockCompTextField.setFont(new Font("monospace", Font.BOLD, 20));
            paperCompTextField.setText(gameStat.getComputerGestureCounts().get(2).toString());
            paperCompTextField.setFont(new Font("monospace", Font.BOLD, 20));
            sciccorsCompTextF.setText(gameStat.getComputerGestureCounts().get(3).toString());
            sciccorsCompTextF.setFont(new Font("monospace", Font.BOLD, 20));
            noOfTies.setText(Integer.toString(gameStat.getTies()));
            noOfTies.setFont(new Font("monospace", Font.BOLD, 20));
            winner.setText(gameStat.getWinner());
            winner.setFont(new Font("monospace", Font.BOLD, 20));
        }
    }
}
